--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10 (Homebrew)
-- Dumped by pg_dump version 14.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE scheduler;
--
-- Name: scheduler; Type: DATABASE; Schema: -; Owner: cassius
--

CREATE DATABASE scheduler WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE scheduler OWNER TO cassius;

\connect scheduler

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: course; Type: TABLE; Schema: public; Owner: cassius
--

CREATE TABLE public.course (
    id integer NOT NULL,
    title text NOT NULL,
    code text NOT NULL,
    updated_at timestamp without time zone DEFAULT '2024-01-01 10:23:54'::timestamp without time zone NOT NULL
);


ALTER TABLE public.course OWNER TO cassius;

--
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: cassius
--

ALTER TABLE public.course ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.courses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: offering; Type: TABLE; Schema: public; Owner: cassius
--

CREATE TABLE public.offering (
    id integer NOT NULL,
    course_id integer NOT NULL
);


ALTER TABLE public.offering OWNER TO cassius;

--
-- Name: offering_id_seq; Type: SEQUENCE; Schema: public; Owner: cassius
--

ALTER TABLE public.offering ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.offering_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: professor; Type: TABLE; Schema: public; Owner: cassius
--

CREATE TABLE public.professor (
    id integer NOT NULL,
    name text,
    avg_rating numeric DEFAULT 2.5 NOT NULL,
    avg_difficulty numeric DEFAULT 2.5 NOT NULL,
    num_ratings integer DEFAULT 1 NOT NULL,
    email text
);


ALTER TABLE public.professor OWNER TO cassius;

--
-- Name: professor_id_seq; Type: SEQUENCE; Schema: public; Owner: cassius
--

ALTER TABLE public.professor ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.professor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: section; Type: TABLE; Schema: public; Owner: cassius
--

CREATE TABLE public.section (
    id integer NOT NULL,
    crn integer NOT NULL,
    credits integer NOT NULL,
    "maxEnrollment" integer NOT NULL,
    enrollment integer NOT NULL,
    start time without time zone DEFAULT '12:00:00'::time without time zone NOT NULL,
    "end" time without time zone DEFAULT '12:50:00'::time without time zone NOT NULL,
    "onMonday" boolean DEFAULT false NOT NULL,
    "onTuesday" boolean DEFAULT false NOT NULL,
    "onWednesday" boolean DEFAULT false NOT NULL,
    "onThursday" boolean DEFAULT false NOT NULL,
    "onFriday" boolean DEFAULT false NOT NULL,
    section_type_id integer NOT NULL,
    professor_id integer
);


ALTER TABLE public.section OWNER TO cassius;

--
-- Name: section_type; Type: TABLE; Schema: public; Owner: cassius
--

CREATE TABLE public.section_type (
    id integer NOT NULL,
    offering_id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.section_type OWNER TO cassius;

--
-- Name: sections_id_seq; Type: SEQUENCE; Schema: public; Owner: cassius
--

ALTER TABLE public.section ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: types_id_seq; Type: SEQUENCE; Schema: public; Owner: cassius
--

ALTER TABLE public.section_type ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: cassius
--

COPY public.course (id, title, code, updated_at) FROM stdin;
\.
COPY public.course (id, title, code, updated_at) FROM '$$PATH$$/3693.dat';

--
-- Data for Name: offering; Type: TABLE DATA; Schema: public; Owner: cassius
--

COPY public.offering (id, course_id) FROM stdin;
\.
COPY public.offering (id, course_id) FROM '$$PATH$$/3695.dat';

--
-- Data for Name: professor; Type: TABLE DATA; Schema: public; Owner: cassius
--

COPY public.professor (id, name, avg_rating, avg_difficulty, num_ratings, email) FROM stdin;
\.
COPY public.professor (id, name, avg_rating, avg_difficulty, num_ratings, email) FROM '$$PATH$$/3701.dat';

--
-- Data for Name: section; Type: TABLE DATA; Schema: public; Owner: cassius
--

COPY public.section (id, crn, credits, "maxEnrollment", enrollment, start, "end", "onMonday", "onTuesday", "onWednesday", "onThursday", "onFriday", section_type_id, professor_id) FROM stdin;
\.
COPY public.section (id, crn, credits, "maxEnrollment", enrollment, start, "end", "onMonday", "onTuesday", "onWednesday", "onThursday", "onFriday", section_type_id, professor_id) FROM '$$PATH$$/3699.dat';

--
-- Data for Name: section_type; Type: TABLE DATA; Schema: public; Owner: cassius
--

COPY public.section_type (id, offering_id, name) FROM stdin;
\.
COPY public.section_type (id, offering_id, name) FROM '$$PATH$$/3697.dat';

--
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cassius
--

SELECT pg_catalog.setval('public.courses_id_seq', 2548, true);


--
-- Name: offering_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cassius
--

SELECT pg_catalog.setval('public.offering_id_seq', 1748, true);


--
-- Name: professor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cassius
--

SELECT pg_catalog.setval('public.professor_id_seq', 3012, true);


--
-- Name: sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cassius
--

SELECT pg_catalog.setval('public.sections_id_seq', 8966, true);


--
-- Name: types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cassius
--

SELECT pg_catalog.setval('public.types_id_seq', 3245, true);


--
-- Name: course course_pkey; Type: CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_pkey PRIMARY KEY (id);


--
-- Name: offering offering_pkey; Type: CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.offering
    ADD CONSTRAINT offering_pkey PRIMARY KEY (id);


--
-- Name: professor professor_email_key; Type: CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.professor
    ADD CONSTRAINT professor_email_key UNIQUE (email);


--
-- Name: professor professor_name_key; Type: CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.professor
    ADD CONSTRAINT professor_name_key UNIQUE (name);


--
-- Name: professor professor_pkey; Type: CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.professor
    ADD CONSTRAINT professor_pkey PRIMARY KEY (id);


--
-- Name: section sections_crn_key; Type: CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT sections_crn_key UNIQUE (crn);


--
-- Name: section sections_pkey; Type: CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: section_type types_pkey; Type: CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.section_type
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: course_title_code_idx; Type: INDEX; Schema: public; Owner: cassius
--

CREATE UNIQUE INDEX course_title_code_idx ON public.course USING btree (title, code);


--
-- Name: offering offering_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.offering
    ADD CONSTRAINT offering_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: section section_professor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT section_professor_fkey FOREIGN KEY (professor_id) REFERENCES public.professor(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: section section_section_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.section
    ADD CONSTRAINT section_section_type_id_fkey FOREIGN KEY (section_type_id) REFERENCES public.section_type(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: section_type types_offering_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cassius
--

ALTER TABLE ONLY public.section_type
    ADD CONSTRAINT types_offering_id_fkey FOREIGN KEY (offering_id) REFERENCES public.offering(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

